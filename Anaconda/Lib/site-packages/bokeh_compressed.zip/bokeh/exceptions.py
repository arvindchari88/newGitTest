class DataIntegrityException(Exception):
    pass

class AuthenticationException(Exception):
    pass
